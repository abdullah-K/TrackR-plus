import static org.junit.Assert.*;
import org.junit.Test;

public class UserAttributesTest{
		@Test
		public void testConstructor(){
  		UserAttributes user = new UserAttributes("./user.json");


		}
}
